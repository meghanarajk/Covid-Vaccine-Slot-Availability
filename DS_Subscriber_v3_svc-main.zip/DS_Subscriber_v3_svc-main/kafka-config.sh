#!/bin/bash
RETRY_COUNT=20
SLEEP_TIME=5
GET_CLUSTER_INFO_URL="$KAFKA_MANAGER_HOST/clusters/cname"
CREATE_CLUSTER_COMMAND="curl 'http://$KAFKA_MANAGER_HOST/clusters' -H 'Connection: keep-alive' -H 'Cache-Control: max-age=0' -H 'Origin: http://$KAFKA_MANAGER_HOST' -H 'Content-Type: application/x-www-form-urlencoded' -H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8' -H 'Referer: http://$KAFKA_MANAGER_HOST/addCluster' -H 'Accept-Encoding: gzip, deflate, br' --data 'name=cname&zkHosts=zookeeper%3A2181&kafkaVersion=2.4.0&jmxUser=&jmxPass=&tuning.brokerViewUpdatePeriodSeconds=30&tuning.clusterManagerThreadPoolSize=2&tuning.clusterManagerThreadPoolQueueSize=100&tuning.kafkaCommandThreadPoolSize=2&tuning.kafkaCommandThreadPoolQueueSize=100&tuning.logkafkaCommandThreadPoolSize=2&tuning.logkafkaCommandThreadPoolQueueSize=100&tuning.logkafkaUpdatePeriodSeconds=30&tuning.partitionOffsetCacheTimeoutSecs=5&tuning.brokerViewThreadPoolSize=4&tuning.brokerViewThreadPoolQueueSize=1000&tuning.offsetCacheThreadPoolSize=4&tuning.offsetCacheThreadPoolQueueSize=1000&tuning.kafkaAdminClientThreadPoolSize=4&tuning.kafkaAdminClientThreadPoolQueueSize=1000&tuning.kafkaManagedOffsetMetadataCheckMillis=30000&tuning.kafkaManagedOffsetGroupCacheSize=1000000&tuning.kafkaManagedOffsetGroupExpireDays=7&securityProtocol=PLAINTEXT&saslMechanism=DEFAULT&jaasConfig=&pollConsumers=true&jmxEnabled=true&activeOffsetCacheEnabled=true&displaySizeEnabled=true' --compressed"
if [[ -z "${KAFKA_CLUSTERS}" ]] || [[ -z "${KAFKA_MANAGER_HOST}" ]]; then
  echo "Provide all configuration options"
  exit
else
	IFS=',' read -r -a clusters <<< "$KAFKA_CLUSTERS"
	echo "Setting up clusters with default settings"
	# Wait for KAFKA manager
	# Check whether host is available
	retries=0
	while [[ "$(curl -s -o /dev/null -w ''%{http_code}'' $KAFKA_MANAGER_HOST)" != "200" ]] && [[ $retries -lt $RETRY_COUNT ]];
	do
		echo "Connecting to $KAFKA_MANAGER_HOST , attempt #$retries"
		retries=$((retries+1))
		sleep $SLEEP_TIME;
	done
	echo "Connected to the Kafka Manager host"
	# Set clusters
	for i in "${clusters[@]}"
	do
		IFS='#' read -r -a clusterinfo <<< "$i"
		address=${clusterinfo[0]}
		name=${clusterinfo[1]}
		echo "Setting up Cluster $address - $name"
		echo "Checking if the cluster already defined"
		effective_url=${GET_CLUSTER_INFO_URL/cname/$name}
		echo "$effective_url"
		result=$(curl -s $effective_url)
		echo "$effective_url"
		if [[ $result == *"Unknown cluster"* ]]; then
			echo "Creating cluster $address - $name"
			effective_command=${CREATE_CLUSTER_COMMAND/cname/$name}
			result=$(eval $effective_command)
			echo "Cluster has been created"
		else
			echo "Cluster already exists"
		fi
	done
fi