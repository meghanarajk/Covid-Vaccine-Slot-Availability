package com.ub.distributedsystem.service;

import com.ub.distributedsystem.mapper.DtoEntityMapper;
import com.ub.distributedsystem.rest.dto.FetchCustomerDTO;
import com.ub.distributedsystem.database.entity.Customer;
import com.ub.distributedsystem.database.repository.CustomerRepository;
import lombok.RequiredArgsConstructor;
import org.mapstruct.factory.Mappers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
/**
 *
 * @author  Manya Singh
 * @version 3.0
 * @since   12-11-2021
 * Customer can login and view their details
 */
@Service
@RequiredArgsConstructor
public class LoginCustomer {

    @Autowired
    private CustomerRepository customerRepository;

    private static final DtoEntityMapper  mapper = Mappers.getMapper(DtoEntityMapper.class);

    public FetchCustomerDTO fetchDetails(String userName, String password) {
        List<Customer> customer = customerRepository.findByUserName(userName);
        if(customer.isEmpty())
            return FetchCustomerDTO.builder().errors(Collections.singletonList("No user found, please Sign Up!")).build();
        if(customer.get(0).getPassword().equals(password)) {
            return FetchCustomerDTO.builder().customerDTO(mapper.mapToCustomerDto(customer.get(0))).build();
        }
        return FetchCustomerDTO.builder().errors(Collections.singletonList("Invalid Password!")).build();
    }
}
