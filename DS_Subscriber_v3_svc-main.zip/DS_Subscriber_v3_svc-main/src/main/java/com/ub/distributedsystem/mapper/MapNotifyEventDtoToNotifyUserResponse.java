package com.ub.distributedsystem.mapper;

import com.ub.distributedsystem.rest.dto.NotifyEventDto;
import com.ub.distributedsystem.service.NotifyUserResponse;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class MapNotifyEventDtoToNotifyUserResponse {
    public List<NotifyUserResponse> mapValue(NotifyEventDto notifyEventDto) {
        return notifyEventDto.getPollingResponse().getSessions().stream()
                .map(sessionDto -> NotifyUserResponse.builder()
                        .centreAddress(sessionDto.address)
                        .dateOfSlotAvailability(sessionDto.date)
                        .slots(sessionDto.slots)
                        .totalAvailableCapacityForDose1(String.valueOf(sessionDto.availableCapacityDose1))
                        .totalAvailableCapacityForDose2(String.valueOf(sessionDto.availableCapacityDose2))
                        .vaccineName(sessionDto.vaccine)
                        .centreName(sessionDto.name)
                        .build())
                .collect(Collectors.toList());
    }
}
