package com.ub.distributedsystem.database.repository;

import com.ub.distributedsystem.database.entity.Notification;
import com.ub.distributedsystem.database.entity.NotificationCompositeKey;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface NotificationRepository extends JpaRepository<Notification, NotificationCompositeKey> {
    boolean existsByNotificationCompositeKey_Username_UserNameIgnoreCaseAndCentreNameIgnoreCaseAndCentreAddressIgnoreCaseAndDateOfSlotAvailabilityIgnoreCaseAndVaccineNameIgnoreCase(String userName, String centreName, String centreAddress, String dateOfSlotAvailability, String vaccineName);

    @Query(value = "SELECT * FROM NOTIFICATION_TABLE nt WHERE nt.username = ?1", nativeQuery = true)
    List<Notification> findByNotificationByUsername(String username);

}
