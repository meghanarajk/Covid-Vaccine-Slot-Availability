package com.ub.distributedsystem.clients.clientrequest;


import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Builder
public class Subscription {
    private String subscriber;
    private Preference event_topic;
    private String port;
}
