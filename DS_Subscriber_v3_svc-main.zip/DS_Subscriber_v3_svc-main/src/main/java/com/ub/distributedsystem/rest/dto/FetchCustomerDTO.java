package com.ub.distributedsystem.rest.dto;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Builder
@Data
public class FetchCustomerDTO {
    private CustomerDTO customerDTO;
    private List<String> errors;
}
