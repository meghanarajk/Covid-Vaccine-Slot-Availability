
package com.ub.distributedsystem.rest.dto;

import com.fasterxml.jackson.annotation.*;
import lombok.Data;

import javax.annotation.Generated;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "center_id",
    "name",
    "address",
    "state_name",
    "district_name",
    "block_name",
    "pincode",
    "from",
    "to",
    "lat",
    "long",
    "fee_type",
    "session_id",
    "date",
    "available_capacity",
    "available_capacity_dose1",
    "available_capacity_dose2",
    "fee",
    "min_age_limit",
    "allow_all_age",
    "vaccine",
    "slots",
    "max_age_limit"
})
@Generated("jsonschema2pojo")
@Data
public class SessionDto {

    @JsonProperty("center_id")
    public Integer centerId;
    @JsonProperty("name")
    public String name;
    @JsonProperty("address")
    public String address;
    @JsonProperty("state_name")
    public String stateName;
    @JsonProperty("district_name")
    public String districtName;
    @JsonProperty("block_name")
    public String blockName;
    @JsonProperty("pincode")
    public Integer pincode;
    @JsonProperty("from")
    public String from;
    @JsonProperty("to")
    public String to;
    @JsonProperty("lat")
    public Integer lat;
    @JsonProperty("long")
    public Integer _long;
    @JsonProperty("fee_type")
    public String feeType;
    @JsonProperty("session_id")
    public String sessionId;
    @JsonProperty("date")
    public String date;
    @JsonProperty("available_capacity")
    public Integer availableCapacity;
    @JsonProperty("available_capacity_dose1")
    public Integer availableCapacityDose1;
    @JsonProperty("available_capacity_dose2")
    public Integer availableCapacityDose2;
    @JsonProperty("fee")
    public String fee;
    @JsonProperty("min_age_limit")
    public Integer minAgeLimit;
    @JsonProperty("allow_all_age")
    public Boolean allowAllAge;
    @JsonProperty("vaccine")
    public String vaccine;
    @JsonProperty("slots")
    public List<String> slots = null;
    @JsonProperty("max_age_limit")
    public Integer maxAgeLimit;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
