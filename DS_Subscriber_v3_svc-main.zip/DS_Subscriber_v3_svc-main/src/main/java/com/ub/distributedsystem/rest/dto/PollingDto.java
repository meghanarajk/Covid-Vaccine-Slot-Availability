package com.ub.distributedsystem.rest.dto;

import lombok.Data;

import java.util.List;

@Data
public class PollingDto {
    private List<SessionDto> sessions;
}
