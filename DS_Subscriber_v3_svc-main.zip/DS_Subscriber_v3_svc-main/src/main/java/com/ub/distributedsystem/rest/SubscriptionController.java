package com.ub.distributedsystem.rest;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ub.distributedsystem.rest.dto.EventsDto;
import com.ub.distributedsystem.rest.dto.NotificationResponseDto;
import com.ub.distributedsystem.rest.dto.NotifyEventDto;
import com.ub.distributedsystem.rest.dto.PreferencesDto;
import com.ub.distributedsystem.service.NotificationService;
import com.ub.distributedsystem.service.SubscriptionService;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@RestController
@RequiredArgsConstructor
@Slf4j
@SessionAttributes({"pincode", "city"})
public class SubscriptionController {

    @Autowired
    private SubscriptionService subscriptionService;

    @Autowired
    private NotificationService notificationService;

    @Autowired
    private ObjectMapper objectMapper;

    @RequestMapping(value = "/getUserPreference",
            consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_FORM_URLENCODED_VALUE},
            method = RequestMethod.POST,
            produces = MediaType.APPLICATION_JSON_VALUE)
    private ModelAndView getUserPreference(PreferencesDto preferencesDto) {
        ModelAndView modelAndView = new ModelAndView("showUserPreferences");
        if (!"na".equals(preferencesDto.getPincode())) {
            modelAndView.addObject("pincode", preferencesDto.getPincode());
        }
        if (!"na".equals(preferencesDto.getLatlong())) {
            modelAndView.addObject("latlong", preferencesDto.getLatlong());
        }
        modelAndView.addObject("city", preferencesDto.getCity());
        subscriptionService.subscribe(preferencesDto);
        return modelAndView;
    }

    @RequestMapping(value = "/unSubscribe",
            consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_FORM_URLENCODED_VALUE},
            method = RequestMethod.POST,
            produces = MediaType.APPLICATION_JSON_VALUE)
    private ResponseEntity<String> unSubscribeFromTopic(PreferencesDto preferencesDto) {
        String response = subscriptionService.unSubscribe(preferencesDto);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping(value = "/notify", consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_FORM_URLENCODED_VALUE},
            produces = MediaType.APPLICATION_JSON_VALUE)
    @SneakyThrows
    public String getNotification(@RequestBody NotifyEventDto notifyEventDto) {
        String notifyUserResponse = notificationService.notifyUser(notifyEventDto);
        ModelAndView modelAndView = new ModelAndView("notifyUserResponse");
        modelAndView.addObject("notifyUserResponse", notifyUserResponse);
        return "Successful";
    }

    @GetMapping(value = "/showNotifications",
            produces = MediaType.APPLICATION_JSON_VALUE)
    private List<NotificationResponseDto> showNotifications(@RequestParam String userName) {
        return notificationService.showNotifications(userName);
    }

    @GetMapping(value = "/fetchUserEventDetails",
            produces = MediaType.APPLICATION_JSON_VALUE)
    private EventsDto showEvents(@RequestParam String userName) {
        return notificationService.showEvents(userName);
    }
}
