package com.ub.distributedsystem.mapper;

import com.ub.distributedsystem.database.entity.Customer;
import com.ub.distributedsystem.database.entity.Notification;
import com.ub.distributedsystem.database.entity.NotificationCompositeKey;
import com.ub.distributedsystem.database.repository.CustomerRepository;
import com.ub.distributedsystem.database.repository.NotificationRepository;
import com.ub.distributedsystem.rest.dto.SessionDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class MapNotifyEventDtoToNotificationEntity {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private NotificationRepository notificationRepository;

    public Notification mapValues(SessionDto sessionDto, String userName) {
        List<Customer> customer = customerRepository.findByUserName(userName);
        NotificationCompositeKey notificationCompositeKey = new NotificationCompositeKey();
        Notification notification = new Notification();
        notification.setCentreAddress(sessionDto.address);
        if (sessionDto.slots != null)
            notification.setSlots(sessionDto.slots.stream().collect(Collectors.joining(",")));
        notification.setCentreName(sessionDto.name);
        if (sessionDto.date != null)
            notification.setDateOfSlotAvailability(sessionDto.date);
        if (sessionDto.availableCapacityDose1 != null)
            notification.setTotalAvailableCapacityForDose1(String.valueOf(sessionDto.availableCapacityDose1));
        if (sessionDto.availableCapacityDose2 != null)
            notification.setTotalAvailableCapacityForDose2(String.valueOf(sessionDto.availableCapacityDose2));
        if (sessionDto.vaccine != null)
            notification.setVaccineName(sessionDto.vaccine);
        notificationCompositeKey.setUsername(customer.get(0));
        notification.setNotificationCompositeKey(notificationCompositeKey);
        return notification;
    }
}
