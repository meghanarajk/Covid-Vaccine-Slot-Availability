package com.ub.distributedsystem.rest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.HashMap;
import java.util.Map;

@Data
public class NotifyEventDto {
    PollingDto pollingResponse;
    @JsonProperty("additionalProperties")
    private Map<String, String> additionalProperties = new HashMap<String, String>();
}
