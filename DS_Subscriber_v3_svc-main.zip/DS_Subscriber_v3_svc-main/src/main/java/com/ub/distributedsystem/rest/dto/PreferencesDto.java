package com.ub.distributedsystem.rest.dto;

import lombok.Data;

import java.util.List;

@Data
public class PreferencesDto {
    String userName;
    String city;
    String pincode;
    String latlong;
}
