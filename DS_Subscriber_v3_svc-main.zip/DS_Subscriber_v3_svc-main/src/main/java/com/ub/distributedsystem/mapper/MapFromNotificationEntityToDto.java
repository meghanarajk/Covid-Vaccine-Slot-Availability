package com.ub.distributedsystem.mapper;

import com.ub.distributedsystem.database.entity.Notification;
import com.ub.distributedsystem.rest.dto.NotificationResponseDto;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class MapFromNotificationEntityToDto {

    public List<NotificationResponseDto> mapToNotificationResponse(List<Notification> notifications) {
        return notifications.stream().map(notification -> NotificationResponseDto.builder()
                .totalAvailableCapacityForDose2(notification.getTotalAvailableCapacityForDose2())
                .centreAddress(notification.getCentreAddress())
                .centreName(notification.getCentreName())
                .dateOfSlotAvailability(notification.getDateOfSlotAvailability())
                .slots(notification.getSlots())
                .totalAvailableCapacityForDose1(notification.getTotalAvailableCapacityForDose1())
                .vaccineName(notification.getVaccineName())
                .build()
        ).collect(Collectors.toList());
    }
}
