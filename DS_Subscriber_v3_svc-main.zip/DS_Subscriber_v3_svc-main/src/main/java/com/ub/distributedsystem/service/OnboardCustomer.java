package com.ub.distributedsystem.service;

import com.ub.distributedsystem.mapper.DtoEntityMapper;
import com.ub.distributedsystem.rest.dto.CustomerDTO;
import com.ub.distributedsystem.database.entity.Customer;
import com.ub.distributedsystem.database.repository.CustomerRepository;
import lombok.RequiredArgsConstructor;
import org.mapstruct.factory.Mappers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
/**
 *
 * @author  Manya Singh
 * @version 3.0
 * @since   12-11-2021
 */
@Service
@RequiredArgsConstructor
public class OnboardCustomer {

    private static final DtoEntityMapper mapper = Mappers.getMapper(DtoEntityMapper.class);

    @Autowired
    private CustomerRepository customerRepository;

    public String createAccount(CustomerDTO request) {
        Customer customer = mapper.mapToCustomer(request);
        Customer savedEntity = customerRepository.save(customer);
        if (savedEntity != null) {
            return "Welcome!Now we can notify when slots are available on your mobile:" + savedEntity.getMobileNumber();
        }
        return "Sorry! some error occurred, please try again in some time";
    }

}
