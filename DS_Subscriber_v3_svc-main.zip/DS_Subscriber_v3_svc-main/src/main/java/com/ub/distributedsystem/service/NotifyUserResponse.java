package com.ub.distributedsystem.service;

import lombok.Builder;
import lombok.Data;

import java.util.List;
/**
 *
 * @author  Manya Singh
 * @version 3.0
 * @since   12-11-2021
 */
@Data
@Builder
public class NotifyUserResponse {
    private String centreName;
    private String centreAddress;
    private String dateOfSlotAvailability;
    private String totalAvailableCapacityForDose1;
    private String totalAvailableCapacityForDose2;
    private String vaccineName;
    private List<String> slots;
}
