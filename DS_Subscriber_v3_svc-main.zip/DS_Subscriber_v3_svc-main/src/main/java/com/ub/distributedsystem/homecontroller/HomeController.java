package com.ub.distributedsystem.homecontroller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class HomeController {

    @RequestMapping(value = "/")
    public String indexPage() {
        return "login";
    }

    @GetMapping(value = "/view")
    @ResponseBody
    public String view() {
        return "Welcome to Registration service";
    }
}
