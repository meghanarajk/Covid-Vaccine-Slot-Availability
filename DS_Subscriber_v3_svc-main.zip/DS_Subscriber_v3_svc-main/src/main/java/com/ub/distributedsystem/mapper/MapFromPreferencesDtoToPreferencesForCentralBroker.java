package com.ub.distributedsystem.mapper;

import com.ub.distributedsystem.clients.clientrequest.Preference;
import com.ub.distributedsystem.database.entity.SubscriptionEntity;
import com.ub.distributedsystem.rest.dto.PreferencesDto;
import org.springframework.stereotype.Service;

import static java.util.Objects.nonNull;

@Service
public class MapFromPreferencesDtoToPreferencesForCentralBroker {
    public Preference mapValues(PreferencesDto preferences) {
        Preference preference = new Preference();
        preference.setByDistrict(true);
        preference.setDistrict(preferences.getCity());
        if (!"na".equals(preferences.getPincode()) && nonNull(preferences.getPincode())) {
            preference.setByPin(true);
            preference.setPin(preferences.getPincode());
        }
        if (!"na".equals(preferences.getLatlong()) && nonNull(preferences.getLatlong())) {
            preference.setByLocation(true);
            preference.setLocation(preferences.getLatlong().replace(" and ", ","));
        }
        return preference;
    }

    public Preference mapValuesForUnsubscribe(PreferencesDto preferences, SubscriptionEntity subscriptionEntity) {
        Preference preference = new Preference();
        if(!nonNull(preferences.getCity()))
            preference.setDistrict(subscriptionEntity.getDistrict());
        if (!nonNull(preferences.getPincode()))
            preference.setPin(subscriptionEntity.getPin());
        if (!nonNull(preferences.getLatlong()))
            preference.setLocation(subscriptionEntity.getLocation());
        return preference;
    }
}
