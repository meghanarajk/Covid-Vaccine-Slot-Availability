package com.ub.distributedsystem;

import com.ub.distributedsystem.config.MyKafkaProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EnableJpaRepositories
@EnableConfigurationProperties(value = {MyKafkaProperties.class})
public class CovidVaccineSlotAvailabilityApplication {

	public static void main(String[] args) {
		SpringApplication.run(CovidVaccineSlotAvailabilityApplication.class, args);
	}

}
