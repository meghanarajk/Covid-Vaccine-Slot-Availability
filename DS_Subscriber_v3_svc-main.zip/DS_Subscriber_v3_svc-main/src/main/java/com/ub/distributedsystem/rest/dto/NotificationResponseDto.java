package com.ub.distributedsystem.rest.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class NotificationResponseDto {
    private String centreName;
    private String centreAddress;
    private String dateOfSlotAvailability;
    private String totalAvailableCapacityForDose1;
    private String totalAvailableCapacityForDose2;
    private String vaccineName;
    private String slots;
}
