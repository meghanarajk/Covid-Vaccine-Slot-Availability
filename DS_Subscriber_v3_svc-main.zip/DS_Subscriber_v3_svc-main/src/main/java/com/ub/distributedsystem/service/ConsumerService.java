package com.ub.distributedsystem.service;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.ub.distributedsystem.database.entity.Notification;
import com.ub.distributedsystem.database.entity.SubscriptionEntity;
import com.ub.distributedsystem.database.repository.NotificationRepository;
import com.ub.distributedsystem.database.repository.SubscriptionRepository;
import com.ub.distributedsystem.mapper.MapNotifyEventDtoToNotificationEntity;
import com.ub.distributedsystem.rest.SubscriptionController;
import com.ub.distributedsystem.rest.dto.NotifyEventDto;
import com.ub.distributedsystem.rest.dto.PollingDto;
import com.ub.distributedsystem.rest.dto.SessionDto;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
/**
 * @author  Manya Singh
 * @version 3.0
 * @since   12-11-2021
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class ConsumerService {

    private final ObjectMapper objectMapper;
    private final SubscriptionRepository subscriptionRepository;
    private final SubscriptionController subscriptionController;
    private final MapNotifyEventDtoToNotificationEntity mapNotifyEventDtoToNotificationEntity;
    private final NotificationRepository notificationRepository;
    /**
     * This method call the cowin client
     * to get the response according to the next date and lat and long provide
     * @param record This is one of record application is receiving.
     */
    @SneakyThrows
    public void processRecord(String record) {
        SessionDto sessionDto = objectMapper.readValue(record, SessionDto.class);
        List<SubscriptionEntity> subscriptions = populateSubscriptions();
        for (SubscriptionEntity subscription : subscriptions) {
            NotifyEventDto notifyEventDto=matchMessageWithSubscription(subscription, sessionDto);
            if(notifyEventDto.getPollingResponse()!=null && notifyEventDto.getPollingResponse().getSessions()!=null){
                subscriptionController.getNotification(notifyEventDto);
            }
        }
    }
    /**
     * This method call the cowin client
     * to get the response according to the next date and lat and long provide
     * @param subscription This is subscription to match
     * @param session This is one of record application is receiving.
     */
    private NotifyEventDto matchMessageWithSubscription(SubscriptionEntity subscription, SessionDto session) {
        NotifyEventDto notifyEventDto = new NotifyEventDto();
        Map<String, String> additionalProperty = new HashMap<>();
        if ((subscription.getPin() != null && session.getPincode() != null && subscription.getPin().length() > 0 && String.valueOf(session.getPincode()).equalsIgnoreCase(subscription.getPin()))
                || (session.getDistrictName() != null && subscription.getDistrict() != null && subscription.getDistrict().equalsIgnoreCase(session.getDistrictName().trim()))
                || (subscription.getLocation() != null && session.getLat() != null && session.get_long() != null && subscription.getLocation().length() > 0 && String.valueOf(session.getLat()).length() >= 2 && String.valueOf(session.getLat()).substring(0, 2).equalsIgnoreCase(subscription.getLocation().split(",")[0].substring(0, 2))
                && String.valueOf(session.get_long()).length() >= 2 && String.valueOf(session.get_long()).substring(0, 2).equalsIgnoreCase(subscription.getLocation().split(",")[1].substring(0, 2)))) {
            additionalProperty.put("username",subscription.getUserId());
            PollingDto pollingDto= new PollingDto();
            if(checkIfNotDuplicate(subscription,session))
            pollingDto.setSessions(Collections.singletonList(session));
            notifyEventDto.setAdditionalProperties(additionalProperty);
            notifyEventDto.setPollingResponse(pollingDto);
        }
        return notifyEventDto;
    }

    private boolean checkIfNotDuplicate(SubscriptionEntity subscription, SessionDto session) {
        Notification notification = mapNotifyEventDtoToNotificationEntity.mapValues(session, subscription.getUserId());
        if(notificationRepository.existsByNotificationCompositeKey_Username_UserNameIgnoreCaseAndCentreNameIgnoreCaseAndCentreAddressIgnoreCaseAndDateOfSlotAvailabilityIgnoreCaseAndVaccineNameIgnoreCase(notification.getNotificationCompositeKey().getUsername().getUserName(),notification.getCentreName(),notification.getCentreAddress(),notification.getDateOfSlotAvailability(),notification.getVaccineName())){
            return false;
        }
        return true;
    }

    private List<SubscriptionEntity> populateSubscriptions() {
        List<SubscriptionEntity> subscriptionEntities = subscriptionRepository.findAll();
        return subscriptionEntities;
    }


}