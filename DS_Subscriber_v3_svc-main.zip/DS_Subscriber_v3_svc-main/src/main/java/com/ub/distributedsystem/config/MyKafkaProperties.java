package com.ub.distributedsystem.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties("mykafka")
@Data
public class MyKafkaProperties {
    public static final String CONSUMER_GROUP_ID = "1";
    private String bootstrapAddress;

}
