package com.ub.distributedsystem.service;

import com.ub.distributedsystem.clients.clientrequest.Preference;
import com.ub.distributedsystem.clients.clientrequest.Subscription;
import com.ub.distributedsystem.database.entity.SubscriptionEntity;
import com.ub.distributedsystem.database.repository.SubscriptionRepository;
import com.ub.distributedsystem.mapper.MapFromPreferencesDtoToPreferencesForCentralBroker;
import com.ub.distributedsystem.rest.dto.PreferencesDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static java.util.Objects.nonNull;
/**
 *
 * @author  Manya Singh
 * @version 3.0
 * @since   12-11-2021
 * Manage subscriptions for users.
 */
@Service
public class SubscriptionService {

    @Autowired
    private MapFromPreferencesDtoToPreferencesForCentralBroker mapFromPreferencesDtoToPreferencesForCentralBroker;

    @Autowired
    private SubscriptionRepository subscriptionRepository;

    public void subscribe(PreferencesDto preferences) {
        Preference preference = mapFromPreferencesDtoToPreferencesForCentralBroker.mapValues(preferences);
        subscriptionRepository.save(SubscriptionEntity.builder()
                .userId(preferences.getUserName())
                .district(preferences.getCity().equals("na") ? null : preferences.getCity())
                .location(preferences.getLatlong().equals("na") ? null : preferences.getLatlong())
                .pin(preferences.getPincode().equals("na") ? null : preferences.getPincode()).build());
        Subscription subscriptionDto = Subscription.builder().subscriber(preferences.getUserName())
                .event_topic(preference).port("8089").build();
        String response = "Subscription Entry";
        if (response.contains("Subscription Entry")) {
            return;
        }
        if (response.contains("tried but no topics given to subscribe to"))
            throw new IllegalArgumentException("Please choose a topic to subscribe to");
        throw new IllegalArgumentException("Some exception occurred while subscribing to event");
    }

    public String unSubscribe(PreferencesDto preferencesDto) {
        SubscriptionEntity subscriptionEntityRetrieved = subscriptionRepository.findById(preferencesDto.getUserName()).get();
        if (nonNull(preferencesDto.getPincode()) && nonNull(preferencesDto.getLatlong()) && nonNull(preferencesDto.getCity()))
            subscriptionRepository.delete(SubscriptionEntity.builder()
                    .userId(preferencesDto.getUserName())
                    .district(preferencesDto.getCity())
                    .location(preferencesDto.getLatlong())
                    .pin(preferencesDto.getPincode()).build());
        else {
            SubscriptionEntity subscriptionToBeSaved = new SubscriptionEntity();
            subscriptionToBeSaved.setUserId(preferencesDto.getUserName());
            if (nonNull(preferencesDto.getPincode())) {
                subscriptionToBeSaved.setPin(null);
            } else {
                subscriptionToBeSaved.setPin(subscriptionEntityRetrieved.getPin());
            }
            if (nonNull(preferencesDto.getCity())) {
                subscriptionToBeSaved.setDistrict(null);
            } else {
                subscriptionToBeSaved.setDistrict(subscriptionEntityRetrieved.getDistrict());
            }
            if (nonNull(preferencesDto.getLatlong())) {
                subscriptionToBeSaved.setLocation(null);
            } else {
                subscriptionToBeSaved.setLocation(subscriptionEntityRetrieved.getLocation());
            }
            subscriptionRepository.save(subscriptionToBeSaved);
        }
        Preference preference = mapFromPreferencesDtoToPreferencesForCentralBroker.mapValuesForUnsubscribe(preferencesDto, subscriptionEntityRetrieved);
        Subscription subscriptionDto = Subscription.builder().subscriber(preferencesDto.getUserName())
                .event_topic(preference).port("8089").build();
        String response = "Successful";
        return response;


    }
}
