package com.ub.distributedsystem.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.TopicPartition;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;
/**
 *
 * @author  Manya Singh
 * @version 3.0
 * @since   12-11-2021
 * This service is getting used to start listener used for various topics and partitions.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class ListenerService {

    private final ConsumerService consumerService;

    @KafkaListener(topicPartitions
            = @TopicPartition(topic = "city_New_Delhi", partitions = {"0"}), groupId = "1")
    public void consumeMessages1(@Payload String message, @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition, @Header(KafkaHeaders.RECEIVED_TOPIC) String topic) {
        log.error("Topic: " + topic + " Partition id: " + partition + "  message: " + message);
        consumerService.processRecord(message);
    }

    @KafkaListener(topicPartitions
            = @TopicPartition(topic = "city_New_Delhi", partitions = {"1"}), groupId = "2")
    public void consumeMessages2(@Payload String message, @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition, @Header(KafkaHeaders.RECEIVED_TOPIC) String topic) {
        log.error("Topic: " + topic + " Partition id: " + partition + "  message: " + message);
        consumerService.processRecord(message);
    }

    @KafkaListener(topicPartitions
            = @TopicPartition(topic = "city_New_Delhi", partitions = {"2"}), groupId = "11")
    public void consumeMessages11(@Payload String message, @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition, @Header(KafkaHeaders.RECEIVED_TOPIC) String topic) {
        log.error("Topic: " + topic + " Partition id: " + partition + "  message: " + message);
        consumerService.processRecord(message);
    }

    @KafkaListener(topicPartitions
            = @TopicPartition(topic = "city_West_Delhi", partitions = {"0"}), groupId = "3")
    public void consumeMessages3(@Payload String message, @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition, @Header(KafkaHeaders.RECEIVED_TOPIC) String topic) {
        log.error("Topic: " + topic + " Partition id: " + partition + "  message: " + message);
        consumerService.processRecord(message);
    }

    @KafkaListener(topicPartitions
            = @TopicPartition(topic = "city_North_Delhi", partitions = {"0"}), groupId = "4")
    public void consumeMessages4(@Payload String message, @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition, @Header(KafkaHeaders.RECEIVED_TOPIC) String topic) {
        log.error("Topic: " + topic + " Partition id: " + partition + "  message: " + message);
        consumerService.processRecord(message);
    }

    @KafkaListener(topicPartitions
            = @TopicPartition(topic = "location_23.836049_77.2167", partitions = {"0"}), groupId = "5")
    public void consumeMessages5(@Payload String message, @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition, @Header(KafkaHeaders.RECEIVED_TOPIC) String topic) {
        log.error("Topic: " + topic + " Partition id: " + partition + "  message: " + message);
        consumerService.processRecord(message);
    }

    @KafkaListener(topicPartitions
            = @TopicPartition(topic = "location_28.628_77.068", partitions = {"0"}), groupId = "6")
    public void consumeMessages6(@Payload String message, @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition, @Header(KafkaHeaders.RECEIVED_TOPIC) String topic) {
        log.error("Topic: " + topic + " Partition id: " + partition + "  message: " + message);
        consumerService.processRecord(message);
    }

    @KafkaListener(topicPartitions
            = @TopicPartition(topic = "location_28.6643_77.209", partitions = {"0"}), groupId = "7")
    public void consumeMessages7(@Payload String message, @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition, @Header(KafkaHeaders.RECEIVED_TOPIC) String topic) {
        log.error("Topic: " + topic + " Partition id: " + partition + "  message: " + message);
        consumerService.processRecord(message);
    }

    @KafkaListener(topicPartitions
            = @TopicPartition(topic = "pin_110012", partitions = {"0"}), groupId = "8")
    public void consumeMessages8(@Payload String message, @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition, @Header(KafkaHeaders.RECEIVED_TOPIC) String topic) {
        log.error("Topic: " + topic + " Partition id: " + partition + "  message: " + message);
        consumerService.processRecord(message);
    }

    @KafkaListener(topicPartitions
            = @TopicPartition(topic = "pin_110012", partitions = {"1"}), groupId = "12")
    public void consumeMessages12(@Payload String message, @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition, @Header(KafkaHeaders.RECEIVED_TOPIC) String topic) {
        log.error("Topic: " + topic + " Partition id: " + partition + "  message: " + message);
        consumerService.processRecord(message);
    }

    @KafkaListener(topicPartitions
            = @TopicPartition(topic = "pin_110041", partitions = {"0"}), groupId = "9")
    public void consumeMessages9(@Payload String message, @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition, @Header(KafkaHeaders.RECEIVED_TOPIC) String topic) {
        log.error("Topic: " + topic + " Partition id: " + partition + "  message: " + message);
        consumerService.processRecord(message);
    }

    @KafkaListener(topicPartitions
            = @TopicPartition(topic = "pin_110042", partitions = {"0"}), groupId = "10")
    public void consumeMessages10(@Payload String message, @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition, @Header(KafkaHeaders.RECEIVED_TOPIC) String topic) {
        log.error("Topic: " + topic + " Partition id: " + partition + "  message: " + message);
        consumerService.processRecord(message);
    }

}

