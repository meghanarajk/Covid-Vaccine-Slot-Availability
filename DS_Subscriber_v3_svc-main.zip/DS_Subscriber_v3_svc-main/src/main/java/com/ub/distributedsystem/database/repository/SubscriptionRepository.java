package com.ub.distributedsystem.database.repository;

import com.ub.distributedsystem.database.entity.SubscriptionEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SubscriptionRepository extends JpaRepository<SubscriptionEntity, String> {
}
