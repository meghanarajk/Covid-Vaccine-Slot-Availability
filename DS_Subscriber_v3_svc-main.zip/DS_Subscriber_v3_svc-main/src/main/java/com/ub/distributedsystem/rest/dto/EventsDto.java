package com.ub.distributedsystem.rest.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EventsDto {
    private String pin;
    private String city;
    private String latlong;
    private String errorMessage;
}
