package com.ub.distributedsystem.service;

import com.ub.distributedsystem.database.entity.Notification;
import com.ub.distributedsystem.database.entity.SubscriptionEntity;
import com.ub.distributedsystem.database.repository.CustomerRepository;
import com.ub.distributedsystem.database.repository.NotificationRepository;
import com.ub.distributedsystem.database.repository.SubscriptionRepository;
import com.ub.distributedsystem.mapper.MapFromNotificationEntityToDto;
import com.ub.distributedsystem.mapper.MapNotifyEventDtoToNotificationEntity;
import com.ub.distributedsystem.mapper.MapNotifyEventDtoToNotifyUserResponse;
import com.ub.distributedsystem.rest.dto.EventsDto;
import com.ub.distributedsystem.rest.dto.NotificationResponseDto;
import com.ub.distributedsystem.rest.dto.NotifyEventDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
/**
 *
 * @author  Manya Singh
 * @version 3.0
 * @since   12-11-2021
 * Manage the notifications for subscribers.
 */
@Service
public class NotificationService {
    @Autowired
    private MapNotifyEventDtoToNotifyUserResponse mapNotifyEventDtoToNotifyUserResponse;

    @Autowired
    private MapFromNotificationEntityToDto mapFromNotificationEntityToDto;

    @Autowired
    private MapNotifyEventDtoToNotificationEntity mapNotifyEventDtoToNotificationEntity;

    @Autowired
    private NotificationRepository notificationRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private SubscriptionRepository subscriptionRepository;

    public String notifyUser(NotifyEventDto notifyEventDto) {
        String userName = notifyEventDto.getAdditionalProperties().get("username");
        List<Notification> listONotifications = notifyEventDto.getPollingResponse().getSessions().stream()
                .map(sessionDto -> mapNotifyEventDtoToNotificationEntity.mapValues(sessionDto, userName))
                .collect(Collectors.toList());
        notificationRepository.saveAll(listONotifications);
        return "list of sessions saved for user: " + userName;
    }

    public List<NotificationResponseDto> showNotifications(String userName) {
        return mapFromNotificationEntityToDto.mapToNotificationResponse(notificationRepository.findByNotificationByUsername(userName));
    }

    public EventsDto showEvents(String userName) {
        Optional<SubscriptionEntity> subscription = subscriptionRepository.findById(userName);
        return subscription.map(subscriptionEntity -> EventsDto.builder()
                .latlong(subscriptionEntity.getLocation())
                .pin(subscriptionEntity.getPin())
                .city(subscriptionEntity.getDistrict()).build())
                .orElseGet(() -> EventsDto.builder().errorMessage("No topics to unsubscribe to please subscribe first").build());
    }
}
