package com.ub.distributedsystem.database.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Builder
@Table(name = "SUBSCRIPTION_TABLE")
public class SubscriptionEntity {
    @Id
    private String userId;
    private String pin;
    private String district;
    private String location;
}
