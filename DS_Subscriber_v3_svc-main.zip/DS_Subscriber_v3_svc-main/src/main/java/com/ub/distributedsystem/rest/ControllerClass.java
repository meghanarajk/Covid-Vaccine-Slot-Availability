package com.ub.distributedsystem.rest;

import com.ub.distributedsystem.rest.dto.FetchCustomerDTO;
import com.ub.distributedsystem.rest.dto.CustomerDTO;
import com.ub.distributedsystem.service.LoginCustomer;
import com.ub.distributedsystem.service.OnboardCustomer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.constraints.NotNull;

@Controller
@SessionAttributes("response")
public class ControllerClass {

    @Autowired
    private OnboardCustomer onboardCustomer;

    @Autowired
    private LoginCustomer loginCustomer;

    @RequestMapping(value = "/onboardCustomer",
            consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_FORM_URLENCODED_VALUE},
            method = RequestMethod.POST,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> customerOnBoarding(CustomerDTO request) {
        String response = onboardCustomer.createAccount(request);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(value = "/login",
            produces = {MediaType.APPLICATION_JSON_VALUE})
    public ModelAndView loginCustomer(@RequestParam @NotNull String userName,
                                                          @RequestParam @NotNull String password) {
        FetchCustomerDTO response = loginCustomer.fetchDetails(userName, password);
        ModelAndView modelAndView = new ModelAndView("showCustomerDetails");
        modelAndView.addObject("response",response);
        return modelAndView;
    }

}
