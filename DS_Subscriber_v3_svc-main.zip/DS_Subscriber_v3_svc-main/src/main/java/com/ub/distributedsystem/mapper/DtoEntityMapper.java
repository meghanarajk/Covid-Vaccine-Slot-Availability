package com.ub.distributedsystem.mapper;


import com.ub.distributedsystem.database.entity.Notification;
import com.ub.distributedsystem.rest.dto.CustomerDTO;
import com.ub.distributedsystem.database.entity.Customer;
import com.ub.distributedsystem.rest.dto.NotificationResponseDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper
public interface DtoEntityMapper {
    @Mapping(target = "id", ignore = true)
    Customer mapToCustomer(CustomerDTO request);
    CustomerDTO mapToCustomerDto(Customer customer);
}
