package com.ub.distributedsystem.clients.clientrequest;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor
public class Preference {

    private Boolean byPin;
    private String pin ;
    private Boolean byDistrict;
    private String district;
    private Boolean byLocation ;
    private String location;

    public Preference() {
        this.byPin = false;
        this.pin = "";
        this.byDistrict = false;
        this.district = "";
        this.byLocation = false;
        this.location = "";

    }

}
