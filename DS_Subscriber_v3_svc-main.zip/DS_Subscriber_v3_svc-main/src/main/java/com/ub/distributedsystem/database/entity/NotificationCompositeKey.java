package com.ub.distributedsystem.database.entity;

import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.io.Serializable;

@Embeddable
@Data
public class NotificationCompositeKey implements Serializable {

    private String id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name="username", nullable=false, referencedColumnName = "userName")
    private Customer username;


    public NotificationCompositeKey(){
        this.id = String.valueOf(java.util.UUID.randomUUID());
    }
}
