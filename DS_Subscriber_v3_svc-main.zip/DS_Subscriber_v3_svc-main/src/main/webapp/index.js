window.onload = function() {
  callme();
};

function callme(){
const userName = document.getElementById("userName").value;
fetch("http://localhost:8089/showNotifications?userName="+userName)
   .then(response => response.json())
   .then(slots => showSlots(slots));
   var timeOutPromise = new Promise(function(resolve, reject) {
     setTimeout(resolve, 30000, 'Timeout Done');
   });

   timeOutPromise.then(function(values) {
     console.log("Timeout Completed, reloading");
     location.reload();
     //Repeat
     callme();
   });
   }


showSlots = slots => {
  const charactersDiv = document.querySelector("#slot-details");
  count = 0
  slots.forEach(slot => {
    count = count + 1
    const numbering = document.createElement("p");
    numbering.innerText = count
    charactersDiv.append(numbering);
    if(null!= slot.centreName){
        const characterElement = document.createElement("p");
        characterElement.innerText = "Centre Name: "+slot.centreName
        charactersDiv.append(characterElement);
    }
    if(null!=slot.centreAddress){
        const centreAddress = document.createElement("p");
        centreAddress.innerText = "Centre Address: "+slot.centreAddress
        charactersDiv.append(centreAddress);
    }
    if(null!=slot.dateOfSlotAvailability) {
        const dateOfSlotAvailability = document.createElement("p");
        dateOfSlotAvailability.innerText = "Date Of Slot Availability: "+slot.dateOfSlotAvailability
        charactersDiv.append(dateOfSlotAvailability);
    }
    if(null!=slot.totalAvailableCapacityForDose1) {
        const totalAvailableCapacityForDose1 = document.createElement("p");
        totalAvailableCapacityForDose1.innerText = "Availability for 1st dose: "+slot.totalAvailableCapacityForDose1
        charactersDiv.append(totalAvailableCapacityForDose1);
    }
    if(null != slot.totalAvailableCapacityForDose2){
        const totalAvailableCapacityForDose2 = document.createElement("p");
        totalAvailableCapacityForDose2.innerText = "Availability for 2nd dose: "+slot.totalAvailableCapacityForDose2
        charactersDiv.append(totalAvailableCapacityForDose2);
    }
    if(null != slot.vaccineName) {
        const vaccineName = document.createElement("p");
        vaccineName.innerText = "Vaccine Name: "+slot.vaccineName
        charactersDiv.append(vaccineName);
    }
    if(null != slot.slots) {
        const slotsTime = document.createElement("p");
        slotsTime.innerText = "Slots: "+slot.slots
        charactersDiv.append(slotsTime);
    }
  });
  if(count == 0){
  const characterElement = document.createElement("p");
  characterElement.innerText = "No notifications check back later";
  charactersDiv.append(characterElement);
  }
}