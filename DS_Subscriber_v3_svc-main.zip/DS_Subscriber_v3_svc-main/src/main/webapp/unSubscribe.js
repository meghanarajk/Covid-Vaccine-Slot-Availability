window.onload = function() {
  callme();
};

function callme(){
console.log("here")
const userName = document.getElementById("userName").value;
console.log(userName)
fetch("http://localhost:8089/fetchUserEventDetails?userName="+userName)
   .then(response => response.json())
   .then(events => showEvents(events, userName));
}


function  showEvents(events, userName){
console.log(userName)
console.log("showEvents")
console.log(events)
 const charactersDiv = document.querySelector("#slot-details");
  var form = document.createElement("form");
  form.setAttribute("method", "post");
  form.setAttribute("action", "unSubscribe");
var br = document.createElement("br");
var userName = document.createElement("input");
    userName.setAttribute("type", "hidden");
    userName.setAttribute("name", "userName");
    userName.setAttribute("value", document.getElementById("userName").value);
    form.appendChild(userName);
    form.appendChild(br.cloneNode());

if(events.city != null){
console.log(events)
  var cityCheckbox = document.createElement("input");
  cityCheckbox.setAttribute("type", "checkbox");
  cityCheckbox.setAttribute("name", "city");
  cityCheckbox.setAttribute("value", events.city);
  var labelForCity = document.createElement('label')
  labelForCity.htmlFor = events.city;
  labelForCity.appendChild(document.createTextNode(events.city));
  form.appendChild(cityCheckbox);
  form.appendChild(labelForCity);
  form.appendChild(br.cloneNode());
  }
  if(events.pin != null){
  console.log(events)
    var pincodeCheckbox = document.createElement("input");
    pincodeCheckbox.setAttribute("type", "checkbox");
    pincodeCheckbox.setAttribute("name", "pincode");
    pincodeCheckbox.setAttribute("value", events.pin);
    var labelForPincode = document.createElement('label')
    labelForPincode.htmlFor = events.pin;
    labelForPincode.appendChild(document.createTextNode(events.pin));
    form.appendChild(pincodeCheckbox);
    form.appendChild(labelForPincode);
    form.appendChild(br.cloneNode());
    }
    if(events.latlong != null){
    console.log(events)
        var latlongCheckbox = document.createElement("input");
        latlongCheckbox.setAttribute("type", "checkbox");
        latlongCheckbox.setAttribute("name", "latlong");
        latlongCheckbox.setAttribute("value", events.latlong);
        var labelForLatlong = document.createElement('label')
        labelForLatlong.htmlFor = events.latlong;
        labelForLatlong.appendChild(document.createTextNode(events.latlong));
        form.appendChild(latlongCheckbox);
        form.appendChild(labelForLatlong);
        form.appendChild(br.cloneNode());
        }
    if(events.latlong!= null || events.city!=null || events.pin!=null){
    var s = document.createElement("input");
                    s.setAttribute("type", "submit");
                    s.setAttribute("value", "Submit");
    form.appendChild(s);
                    }
    document.getElementsByTagName("body")[0]
                   .appendChild(form);
  if(events.errorMessage != null){
  console.log(events)
  const characterElement = document.createElement("p");
  characterElement.innerText = events.errorMessage;
  charactersDiv.append(characterElement);
  }
}
