# DS_Subscriber_v3_svc

## System Setup to run the application
1. clone the application: run the command-> git clone https://github.com/manya0810/DS_Subscriber_v3_svc
2. import project on Intellij and execute the command -> execute gradlew clean build to build the Project.
3. Execute the command docker-compose up to run commands in docker-compose.yml

## Prerequistes for System:
1. Java11
2. IDE: Intellij or Eclipse
3. Docker

## Technology used:
1.Java
2.Spring Boot
3.Docker
4.Spring Data JPA
5.MapStruct
6.Lombok
7.HTML
8.JavaScript
