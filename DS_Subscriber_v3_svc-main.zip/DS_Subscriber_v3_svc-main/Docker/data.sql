DROP TABLE IF EXISTS NOTIFICATION_TABLE;
DROP TABLE IF EXISTS CUSTOMER_TABLE;
DROP Table If EXISTS subscription_table;

CREATE TABLE CUSTOMER_TABLE (
  id VARCHAR(250) PRIMARY KEY,
  first_name VARCHAR(250) NOT NULL,
  last_name VARCHAR(250) NOT NULL,
  email VARCHAR(250) NOT NULL,
  user_name VARCHAR(250) NOT NULL UNIQUE,
  password VARCHAR(250) NOT NULL,
  city VARCHAR(250) NOT NULL,
  pin_code VARCHAR(250) NOT NULL,
  state VARCHAR(250) NOT NULL,
  mobile_number VARCHAR(250) NOT NULL);


CREATE TABLE NOTIFICATION_TABLE (
  id VARCHAR(250),
  username VARCHAR(250) REFERENCES CUSTOMER_TABLE(user_name),
  centre_name VARCHAR(250) NOT NULL,
  centre_address VARCHAR(250) ,
  date_of_slot_availability VARCHAR(250),
  total_available_capacity_for_dose1 VARCHAR(250),
  total_available_capacity_for_dose2 VARCHAR(250) ,
  vaccine_name VARCHAR(250),
  slots VARCHAR(500) ,
  PRIMARY KEY(id,username));

CREATE TABLE SUBSCRIPTION_TABLE (
  user_id VARCHAR(250) PRIMARY KEY,
  pin VARCHAR(250) ,
  district VARCHAR(250) ,
  location VARCHAR(250));

select * from CUSTOMER_TABLE;
select * from NOTIFICATION_TABLE;
select count(*) from notification_table;
select * from subscription_table;


